// 'use strict';

// Declare app level module which depends on views, and components
angular.module('myApp', [])

    .controller('View1Ctrl', function ($scope, $http) {
        $scope.venueList = new Array();
        $scope.mostRecentReview;
        $scope.getVenues = function () {
            var placeEntered = document.getElementById("txt_placeName").value;
            var searchQuery = document.getElementById("txt_searchFilter").value;
            if (searchQuery != null && searchQuery != "") {

                //This is the API that gives the list of venues based on the place and search query.
                /*   var handler = $http.get("https://api.foursquare.com/v2/venues/search" +
                       "?client_id=<Provide your client id>" +
                       "&client_secret=<Provide your client secret>" +
                       "&v=20160215&limit=5" +
                       "&near=" + placeEntered +
                       "&query=" + searchQuery); */

                var handler = $http.get("https://api.github.com/search/repositories" +
                    "?q=" +searchQuery  +
                    "+&sort=stars&order=desc");

                handler.success(function (data) {
                    if (data != null) {
                        console.log(data.items);
                        console.log(data.items.length);
                        $scope.venueList = data.items;
                        // Tie an array named "venueList" to the scope which is an array of objects.
                        // Each object should have key value pairs where the keys are "name", "id" , "location" and values are their corresponding values from the response
                        // Marks will be distributed between logic, implementation and UI


                    }
                })
                handler.error(function (data) {
                    console.log("failure");
                    alert("There was some error processing your request. Please try after some time.");
                });
            }
        }
    });
